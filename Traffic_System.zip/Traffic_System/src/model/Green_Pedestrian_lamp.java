/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author agh
 */
public class Green_Pedestrian_lamp extends PedestrianLamp{
    RedLamp R=new RedLamp();
    GreenLamp G=new GreenLamp();
    YellowLamp Y=new YellowLamp();
    public void AllowStreetCrossing(PedestrianButton button){
        if(button.ButtonPressed==true){
            Y.ActivateYellowLight();
            R.ActivateRedLight();
               for(int i = 15; i >=0; i--){               
         System.out.println(i);
         
    }
               G.ActivateGreenLight();
}
      
    }
     public void ActivateGreenPedestrianLight(){
            new Thread(new Runnable() {
            @Override
            public void run() {
          for(int i = 18; i >=0; i--){               
    System.out.println(i);
                }
     //     y.ActivateYellowLight();
        
            }  
         }).start();
}
}
