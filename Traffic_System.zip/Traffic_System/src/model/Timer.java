/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import esper.Config;
import events.ChangeColor;
import java.util.logging.Level;
import java.util.logging.Logger;
import static model.Color.GREEN;
import static model.Color.RED;
import static model.Color.YELLOW;

/**
 *
 * @author agh
 */
public class Timer {
     int TimerID;

   Traffic_Light GUI;
   
    Color color;
    

    public Timer() {
    }

    public Timer( Traffic_Light GUI) {
       
        this.GUI = GUI;
     
    }



  


    public int getTimerID() {
        return TimerID;
    }

    public void setTimerID(int TimerID) {
        this.TimerID = TimerID;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
    public void ChangeColorLightAtMidnight(boolean Midnight){
       while(Midnight==true){
         YellowLamp yellow=new YellowLamp();
         yellow.ActivateYellowLight();
            
        }
       GreenLamp green=new GreenLamp();
       green.ActivateGreenLight();
    }
   
   
  
    public void SetTimer(int timer)throws InterruptedException{
        
         new Thread(new Runnable() {
            @Override
            public void run() {
             try {
              int time=timer;
   while (true) {
            
//            System.out.println(time);
//              GUI.getGUI().getLeft_red_lamp().setText(String.valueOf(time));

        while(time >= 0){
            

            GUI.getGUI().getLeft_red_lamp().setText(String.valueOf(time));
            GUI.getGUI().getLeft_yellow_lamp().setEnabled(false);
            GUI.getGUI().getLeft_red_lamp().setEnabled(true);
            GUI.getGUI().getLeft_green_lamp().setEnabled(false);
            time--;
            Thread.sleep(500);
            System.out.println(time);
//            Config.sendEvent(new ChangeColor(true ,Color.YELLOW ,timer));
        }
        time=5;
        while(time >= 0){
            
//            redLamp.ActivateRedLight();
        GUI.getGUI().getLeft_yellow_lamp().setText(String.valueOf(time));
            GUI.getGUI().getLeft_yellow_lamp().setEnabled(true);
            GUI.getGUI().getLeft_red_lamp().setEnabled(false);
            GUI.getGUI().getLeft_green_lamp().setEnabled(false);
            time--;
//          Thread.sleep(500);
//            System.out.println(time);
//            Config.sendEvent(new ChangeColor(true ,Color.YELLOW ,timer));
        }
        time=30;
        while(time >= 0){
            
//            redLamp.ActivateRedLight();
             GUI.getGUI().getLeft_green_lamp().setText(String.valueOf(time));
            GUI.getGUI().getLeft_yellow_lamp().setEnabled(false);
            GUI.getGUI().getLeft_red_lamp().setEnabled(false);
            GUI.getGUI().getLeft_green_lamp().setEnabled(true);
            time--;
//            Thread.sleep(500);
//            System.out.println(time);
//            Config.sendEvent(new ChangeColor(true ,Color.YELLOW ,timer));
        }
        time=20;
        time--;
        }
            } catch (InterruptedException ex) {
                Logger.getLogger(Timer.class.getName()).log(Level.SEVERE, null, ex);
            }
            
    }
            
  }).start();
           }     
    }        
    
            
      
        
  



            

