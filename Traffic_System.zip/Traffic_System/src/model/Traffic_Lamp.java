/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import esper.Config;
import events.ChangeColor;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author agh
 */
public class Traffic_Lamp extends Thread{
    int ID;
    String Location;
    int timer;

    public Traffic_Lamp() {
        timer=20;
    }

    public int getTimer() {
        return timer;
    }

    public Traffic_Lamp(int ID, String Location, int timer) {
        this.ID = ID;
        this.Location = Location;
        this.timer = 20;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }


    public void SwitchLightColor(){
      
    }
     @Override
    public void run() {
        while (true) {
            
            try {
                this.sleep(1000);
            } catch (InterruptedException ex) {
                Logger.getLogger(Traffic_Lamp.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            Config.sendEvent(new ChangeColor(timer));
        }
    }
    
}
