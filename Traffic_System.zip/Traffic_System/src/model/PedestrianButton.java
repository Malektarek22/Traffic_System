/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author agh
 */
class PedestrianButton {
    int ButtonID;
    boolean ButtonPressed;
   public Color color;
   Green_Pedestrian_lamp Allow;
    Red_Pedestrian_lamp Reject;
    public PedestrianButton() {
    }

    public PedestrianButton(int ButtonID, boolean ButtonPressed) {
        this.ButtonID = ButtonID;
        this.ButtonPressed = ButtonPressed;
    }

    public int getButtonID() {
        return ButtonID;
    }

    public void setButtonID(int ButtonID) {
        this.ButtonID = ButtonID;
    }

    public boolean isButtonPressed() {
        return ButtonPressed;
    }

    public void setButtonPressed(boolean ButtonPressed) {
        this.ButtonPressed = ButtonPressed;
    }
    public void RequestStreetCrossing(PedestrianButton ButtonPressed){
       switch (color) {
                    case RED:
                        Allow.AllowStreetCrossing(ButtonPressed);
                        
                        break;
                    case GREEN:
                        Reject.RejectStreetCrossing(ButtonPressed);
                        break;
        }
        
}

}