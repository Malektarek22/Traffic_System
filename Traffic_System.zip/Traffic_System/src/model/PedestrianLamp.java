/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author agh
 */
public class PedestrianLamp {
    int id;
    String Location;
    Timer timer;
    PedestrianButton button;

    public PedestrianLamp(int id, String Location, Timer timer, PedestrianButton button) {
        this.id = id;
        this.Location = Location;
        this.timer = timer;
        this.button = button;
    }

    public PedestrianLamp() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public Timer getTimer() {
        return timer;
    }

    public void setTimer(Timer timer) {
        this.timer = timer;
    }

    public PedestrianButton getButton() {
        return button;
    }

    public void setButton(PedestrianButton button) {
        this.button = button;
    }
    
}
