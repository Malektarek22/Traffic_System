/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author agh
 */
public class YellowLamp extends Traffic_Lamp{
    RedLamp R=new RedLamp();
    public YellowLamp() {
    }
    
    public YellowLamp(int ID, String Location, Timer timer) {
     //   super(ID, Location, timer);
    }
    public void ActivateYellowLight(){
        
        for(int i = 5; i >=0; i--){               
//         System.out.println(i);
                }
        R.ActivateRedLight();
      
    }
    
}
