/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.logging.Level;
import java.util.logging.Logger;
import static model.Color.GREEN;

/**
 *
 * @author agh
 */
public class GreenLamp extends Thread{
   
    YellowLamp y=new YellowLamp();
//    public GreenLamp(int ID, String Location, Timer timer) {
//        super(ID, Location, timer);
//    }

    public GreenLamp() {
    }

   
    public void ActivateGreenLight(){
         new Thread(new Runnable() {
            @Override
            public void run() {
          for(int i = 30; i >=0; i--){               
    System.out.println(i);
                }
     //     y.ActivateYellowLight();
        try {
                        Thread.sleep(500);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(GreenLamp.class.getName()).log(Level.SEVERE, null, ex);
                    }
            }
            
         }).start();
    
}
}
