/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import esper.Config;
import events.ChangeColor;

import view.Traffic;

/**
 *
 * @author agh
 */
public class Traffic_Light extends Thread{
    
    Traffic GUI = new Traffic(); 
    Timer timer;
    Color color;
    GreenLamp greenLamp;
    RedLamp redLamp;
    YellowLamp yellowLamp;
    Green_Pedestrian_lamp greenPedestarianLamp;
    PedestrianButton pedestrianButton ;
    PedestrianLamp pedestrianLamp;
    Red_Pedestrian_lamp redPedestrianLamp;
    Traffic_Lamp trafficLamp;

    
    private CrowdSensor_EW_Interface eastTraffic; 
    private CrowdSensor_EW_Interface westTraffic; 
    private CrowdSensor_NS_Interface southTraffic;
    private CrowdSensor_NS_Interface northTraffic;

    public Traffic_Light()  {
        GUI = new Traffic();
        
        
        GUI.setLocationRelativeTo(null);
        GUI.setVisible(true);
         GUI.getLeft_yellow_lamp().setEnabled(false);
         GUI.getLeft_red_lamp().setEnabled(true);
         GUI.getLeft_green_lamp().setEnabled(false);
//           GUI.getLeft_red_lamp().setText(String.valueOf(timer));
        eastTraffic = new EastTraffic(); 
        westTraffic = new WestTraffic(); 
        southTraffic = new SouthTraffic();
        northTraffic = new NorthTraffic();
        
        this.timer = new Timer(this);
        greenLamp = new GreenLamp();
        redLamp = new RedLamp();
        yellowLamp = new YellowLamp();
        greenPedestarianLamp = new Green_Pedestrian_lamp();
        pedestrianButton = new PedestrianButton();
        pedestrianLamp = new PedestrianLamp();
        redPedestrianLamp = new Red_Pedestrian_lamp();
        trafficLamp = new Traffic_Lamp();
        
        trafficLamp.start();
    }

    public void switchColors(int time) throws InterruptedException{
       
   timer.SetTimer(time);
//        GUI.getLeft_red_lamp().setText(String.valueOf(time));
////        timer.SetTimer(color.GREEN);
//        while(true){
//        while(time >= 0){
//            
////            redLamp.ActivateRedLight();
//       GUI.getLeft_red_lamp().setText(String.valueOf(time));
//            GUI.getLeft_yellow_lamp().setEnabled(false);
//            GUI.getLeft_red_lamp().setEnabled(true);
//            GUI.getLeft_green_lamp().setEnabled(false);
//            time--;
//           sleep(500);
//            System.out.println(time);
////            Config.sendEvent(new ChangeColor(true ,Color.YELLOW ,timer));
//        }
//        time=5;
//        while(time >= 0){
//            
////            redLamp.ActivateRedLight();
//        GUI.getLeft_yellow_lamp().setText(String.valueOf(time));
//            GUI.getLeft_yellow_lamp().setEnabled(true);
//            GUI.getLeft_red_lamp().setEnabled(false);
//            GUI.getLeft_green_lamp().setEnabled(false);
//            time--;
//           sleep(500);
//            System.out.println(time);
////            Config.sendEvent(new ChangeColor(true ,Color.YELLOW ,timer));
//        }
//        time=30;
//        while(time >= 0){
//            
////            redLamp.ActivateRedLight();
//             GUI.getLeft_green_lamp().setText(String.valueOf(time));
//            GUI.getLeft_yellow_lamp().setEnabled(false);
//            GUI.getLeft_red_lamp().setEnabled(false);
//            GUI.getLeft_green_lamp().setEnabled(true);
//            time--;
//           sleep(500);
//            System.out.println(time);
////            Config.sendEvent(new ChangeColor(true ,Color.YELLOW ,timer));
//        }
//        time=20;
//        time--;
//    
//    }
    }
    
    public Traffic getGUI() {
        return GUI;
    }

    public Timer getTimer() {
        return timer;
    }

    public GreenLamp getGreenLamp() {
        return greenLamp;
    }

    public RedLamp getRedLamp() {
        return redLamp;
    }

    public YellowLamp getYellowLamp() {
        return yellowLamp;
    }

    public Green_Pedestrian_lamp getGreenPedestarianLamp() {
        return greenPedestarianLamp;
    }

    public PedestrianButton getPedestrianButton() {
        return pedestrianButton;
    }

    public PedestrianLamp getPedestrianLamp() {
        return pedestrianLamp;
    }

    public Red_Pedestrian_lamp getRedPedestrianLamp() {
        return redPedestrianLamp;
    }

    public Traffic_Lamp getTrafficLamp() {
        return trafficLamp;
    }

    public CrowdSensor_EW_Interface getEastTraffic() {
        return eastTraffic;
    }

    public CrowdSensor_EW_Interface getWestTraffic() {
        return westTraffic;
    }

    public CrowdSensor_NS_Interface getSouthTraffic() {
        return southTraffic;
    }

    public CrowdSensor_NS_Interface getNorthTraffic() {
        return northTraffic;
    }
    
         
    
    
}
