/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Random;

/**
 *
 * @author agh
 */
public class WestTraffic implements CrowdSensor_EW_Interface{
    String Location;
    Traffic_Lamp traffic;
       private int Cars;
 GreenLamp G=new GreenLamp();
 RedLamp R=new RedLamp();
    public String getLocation() {
        return Location;
    }

    public void setLocation(String Location) {
        this.Location = Location;
    }

    public Traffic_Lamp getTraffic() {
        return traffic;
    }

    public void setTraffic(Traffic_Lamp traffic) {
        this.traffic = traffic;
    }

 private int random(int min, int max) {
        
        if (min >= max) {
            throw new IllegalArgumentException("max must be greater than min");
        }
        
        Random r = new Random();
        return r.nextInt((max - min) + 1) + min;
    }
  @Override
    public void DetectCarsArrival() {
           new Thread(new Runnable() {
            @Override
            public void run() {
          while (Cars > 20) {
             G.ActivateGreenLight();         
            Cars -= random(8, 10);
             System.out.println(Cars);
         }
            }  
         }).start();
        
       
         }
    
    @Override
    public void DetectCarsDeparture() {
              new Thread(new Runnable() {
            @Override
            public void run() {
          while (Cars < 20) {
             G.ActivateGreenLight();         
            Cars += random(8, 10);
             System.out.println(Cars);
         }
            }  
         }).start();
        
       
         }
    
}
