/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esper;

import model.Color;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import model.Timer;
import model.Traffic_Light;
import model.NorthTraffic;

/**
 *
 * @author agh
 */
public class Traffic_System {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
        // TODO code application logic here
          // Disable logging
        Logger.getRootLogger().setLevel(Level.OFF);

        // Register events
        Config.registerEvents();
        
       final Traffic_Light trafficLight = new Traffic_Light();
       final Timer t=new Timer();
//          Traffic_Light t = new Traffic_Light();
//        
//        t.SwitchLightColor();
//         NorthTraffic N=new NorthTraffic();
//        N.DetectCarsArrival();
 
        Config.createStatement("select timer from ChangeColor")
                .setSubscriber(new Object() {
                    public void update(int time) throws InterruptedException {
                         trafficLight.switchColors(time);
                    }
                });
    }
    
}
