/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package events;
import model.Color;
/**
 *
 * @author rawanosama
 */
public class ChangePedestrian {
    public boolean state;
    public Color colors;
    public int timer;

    public ChangePedestrian(boolean state, Color colors, int timer) {
        this.state = state;
        this.colors = colors;
        this.timer = timer;
    }

    public boolean isState() {
        return state;
    }

    public Color getColors() {
        return colors;
    }

    public int getTimer() {
        return timer;
    }
    
    
}
