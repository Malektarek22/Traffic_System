
package events;
import model.Color;

/**
 *
 * @author rawanosama
 */
public class ChangeColor { 
    public boolean state;
    public Color colors;
    public int timer;

    public ChangeColor(int timer) {
        this.timer = timer;
    }

  
    
    public ChangeColor(boolean state, Color colors, int timer) {
        this.state = state;
        this.colors = colors;
        this.timer = timer;
    }

    public int getTimer() {
        return timer;
    }


    public boolean isState() {
        return state;
    }

   

    public Color getColors() {
        return colors;
    }

   

  
}
