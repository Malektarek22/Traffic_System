/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package events;

/**
 *
 * @author rawanosama
 */
public class DetectCarArrival {
    public boolean State;
    public int CarCount;
    public String TrafficLocation;

    public DetectCarArrival(boolean State) {
        this.State = State;
    }

    public DetectCarArrival(boolean State, int CarCount, String TrafficLocation) {
        this.State = State;
        this.CarCount = CarCount;
        this.TrafficLocation = TrafficLocation;
    }

    public boolean isState() {
        return State;
    }

   

    public int getCarCount() {
        return CarCount;
    }


    public String getTrafficLocation() {
        return TrafficLocation;
    }

   
    
   
            
}
