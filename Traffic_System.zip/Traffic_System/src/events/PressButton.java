
package events;

/**
 *
 * @author rawanosama
 */
public class PressButton {
    public boolean state;

    public PressButton(boolean state) {
        this.state = state;
    }

    public boolean isState() {
        return state;
    }
    
}
